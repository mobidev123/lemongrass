export function makePercentage(percentage){
    return percentage.toString() + "%"
};