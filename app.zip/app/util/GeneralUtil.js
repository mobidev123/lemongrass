export function prettyPrint(o){
  console.log(JSON.stringify(o, null, 2))
}